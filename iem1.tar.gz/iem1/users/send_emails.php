<?php
/**
* This is a placeholder file so people don't need to change their cron job settings.
*
* @version     $Id: send_emails.php,v 1.2 2007/03/26 08:08:29 chris Exp $
* @author Chris <chris@interspire.com>
*
* @package SendStudio
*/

/**
* Include the file that actually does all of the work.
*/
require_once(dirname(__FILE__) . '/../admin/cron/send.php');
