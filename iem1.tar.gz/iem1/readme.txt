===== Interspire Email Marketer Readme.txt =====

If you are installing Email Marketer, please follow this link:
https://www.interspire.com/installations-and-migrations


If you are upgrading, please follow this link:
https://www.interspire.com/upgrading


===== Email Marketer Documentation =====

For all Email Marketer Documentation:
https://www.interspire.com/documentation

Knowledge Base:
https://www.interspire.com/support/kb
