Place previews of your user templates here using the ID_preview.gif
example:
2_preview.gif